export const setUserName = value =>{
    return {
        type: 'SET_USERNAME',
        payload: value
    }
}
