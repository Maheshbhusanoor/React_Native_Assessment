/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
    SafeAreaView,
    StyleSheet,
    View,
    Text,
    TextInput,
    Button,
    StatusBar,
} from 'react-native';
import {
  
    Colors,
} from 'react-native/Libraries/NewAppScreen';
import { useSelector } from "react-redux";

const PageOne: () => React$Node = ({ navigation }) => {
    const userNameFromStore = useSelector(state => state.userReducer);

    const handleClick = (navTo) => {
        navigation.navigate(navTo);
    }
    return (
        <>
            <StatusBar barStyle="dark-content" />
            <SafeAreaView style={styles.container}>
            <View style={{ flex: 2, justifyContent:'center' }}>
                    <View style={styles.sectionContainer}>
                        <Text style={styles.sectionTitle}>Welcome {userNameFromStore}</Text>
                        
                    </View>
                    <View style={styles.separator} />
                   
                </View>
                <View style={{ width: '50%', flex: 2 , justifyContent:'space-around'}}>
                 
                <View  >
                     <Button
                         title="Go To Page Two "
                         onPress={() => handleClick("PageTwo")}
                     />
                 </View>
                 <View >
                     <Button
                         title="Back to Home "
                         onPress={() => navigation.popToTop()}
                     />
                 </View>
                 
             </View>

            </SafeAreaView>
        </>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        // backgroundColor: 'green',

    },
    separator: {
        marginVertical: 8,
        borderBottomColor: '#737373',
        borderBottomWidth: StyleSheet.hairlineWidth,
    },
    sectionTitle: {
        fontSize: 24,
        fontWeight: '600',
        textAlign: 'center',
        color: Colors.black,
    },
    sectionDescription: {
        marginTop: 8,
        fontSize: 18,
        fontWeight: '400',
        textAlign: 'center',
        color: Colors.dark,
    },
 
});

export default PageOne;
