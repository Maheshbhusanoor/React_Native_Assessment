/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, { useEffect, useState } from 'react';
import {
    SafeAreaView,
    StyleSheet,
    View,
    Text,
    TextInput,
    Button,
    StatusBar,
    TouchableHighlight,
} from 'react-native';
import {

    Colors,
} from 'react-native/Libraries/NewAppScreen';
import DeviceInfo from 'react-native-device-info';
import SwipeButton from 'rn-swipe-button';
import { useSelector, useDispatch } from "react-redux";
import { setUserName } from '../../actions';
import Icon from 'react-native-vector-icons/FontAwesome';
const WelcomePage: () => React$Node = ({ navigation }) => {
    const [runningOn, setRunningOn] = useState("");
    const [userName, bindUserValue] = React.useState('');
    const [slideStatus, setSlideStatus] = React.useState('');
    const [usedDeviceText, setUsedDeviceTest] = React.useState(' You are using : ');
    const userNameFromStore = useSelector(state => state.userReducer);
    const FacebookIcon = () => <Icon name="diamond" color="#3b5998" size={20} />;
    const dispatch = useDispatch();
    useEffect(() => {
        DeviceInfo.isEmulator().then(isEmulator => {
            // console.log("IsEmulator ? : " + isEmulator)
            if (isEmulator) {
                setRunningOn("Emulator");
            } else {
                setRunningOn(DeviceInfo.getModel());
            }
        });

    }, [])

    const handleClick = (navTo) => {
        navigation.navigate(navTo);
    }
  
    return (
        <>
            <StatusBar barStyle="dark-content" />
            <SafeAreaView style={styles.container}>

                <View style={{ flex: 2, justifyContent: 'center' }}>
                    {/* <View style={styles.separator} /> */}
                    <View style={styles.sectionContainer}>
                        <Text style={styles.sectionTitle}>Welcome {userNameFromStore}</Text>
                        <Text style={styles.sectionDescription}>
                            {usedDeviceText} {runningOn}
                        </Text>
                    </View>
                    <View style={styles.separator} />
                    <Text style={styles.sectionDescription}>
                        {slideStatus}
                    </Text>
                </View>

                {userNameFromStore ? <View style={{ flex: 2, justifyContent: 'center' }}>
                    <View  >
                        <TextInput
                            style={{ height: 40, width: 180, borderColor: 'gray', borderWidth: 1 }}
                            onChangeText={text => bindUserValue(text)}
                            value={userName}
                            placeholder="Enter Your Name Here"
                        />
                    </View>
                    <View style={styles.separator} />
                   
                </View> : null}
                <View style={{ width: 230, flex: 2, justifyContent: 'space-around' }}>
                <View >
                      
                      <TouchableHighlight onPress={() => dispatch(setUserName(userName))}>
                         <View style={{alignItems: "center"}}>
                             <Text style={{ color: "#70aff4" }}>Submit Your Name</Text>
                         </View>
                     </TouchableHighlight>
                 </View>
                    <View >
                        <TouchableHighlight onPress={() => handleClick('PageOne')}>
                            <View style={styles.buttonPageOne}>
                                <Text style={{ color: "#fff" }}>Go To Page One</Text>
                            </View>
                        </TouchableHighlight>
                    </View>
                    <View >
                        <TouchableHighlight onPress={() => handleClick('PageTwo')}>
                            <View style={styles.buttonPageTwo}>
                                <Text>Go To Page Two</Text>
                            </View>
                        </TouchableHighlight>
                    </View>

                    <View>
                       
                        <SwipeButton
                            disabled={false}
                            //disable the button by doing true (Optional)
                            swipeSuccessThreshold={99}
                            height={45}
                            thumbIconComponent={FacebookIcon}
                            //height of the button (Optional)
                            width={230}
                            //width of the button (Optional)
                            title="Slide me to continue"
                            //Text inside the button (Optional)
                            //thumbIconImageSource={thumbIcon}
                            //You can also set your own icon for the button (Optional)
                            onSwipeStart={() => setSlideStatus('Swipe started!')}
                            onSwipeFail={() => setSlideStatus('Incomplete swipe!')}
                            onSwipeSuccess={() =>
                                setSlideStatus('Swipe Submitted successfully!')}
                            titleFontSize={14}
                            titleColor="#70aff4"
                            //After the completion of swipe (Optional)
                            railFillBackgroundColor="#6eb1f7" //(Optional)
                            // railFillBorderColor="#e688ff" //(Optional)
                            thumbIconBackgroundColor="#70aff4" //(Optional)
                            // thumbIconBorderColor="#ed9aff" //(Optional)
                            railBackgroundColor="#1b1924" //(Optional)
                            railBorderColor="#bbeaff" //(Optional)
                        />
                    </View>

                </View>

            </SafeAreaView>
        </>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        // backgroundColor: 'green',

    },
    buttonPageOne: {
        alignItems: "center",
        backgroundColor: "#34434a",
        borderRadius: 5,
        padding: 10
    },
    buttonPageTwo: {
        alignItems: "center",
        backgroundColor: "#6eb1f7",
        borderRadius: 5,
        padding: 10
    },
    separator: {
        marginVertical: 8,
        borderBottomColor: '#737373',
        borderBottomWidth: StyleSheet.hairlineWidth,
    },
    sectionTitle: {
        fontSize: 24,
        fontWeight: '600',
        textAlign: 'center',
        color: Colors.black,
    },
    sectionDescription: {
        marginTop: 8,
        fontSize: 18,
        fontWeight: '400',
        textAlign: 'center',
        color: Colors.dark,
    },

});

export default WelcomePage;
