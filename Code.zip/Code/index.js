/**
 * @format
 */

import {AppRegistry} from 'react-native';
import {name as appName} from './app.json';
import RouterStack from './routes/RouterStack';

AppRegistry.registerComponent(appName, () => RouterStack);
