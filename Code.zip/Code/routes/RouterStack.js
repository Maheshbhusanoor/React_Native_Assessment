
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import PageOne from '../components/PageOne/PageOne';
import PageTwo from '../components/PageTwo/PageTwo';
import WelcomePage from '../components/WelcomePage/WelcomePage';
import { StyleSheet, Text, View, Button } from 'react-native';
import { Provider } from 'react-redux';
import allReducers from '../reducers';
import { createStore } from 'redux';
// import Redux from "redux-thunk" 
const Stack = createStackNavigator();

const MyStack = () => {
    const store = createStore(allReducers, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());
  return (
    <Provider store={store}>
    <NavigationContainer>
      <Stack.Navigator 
       screenOptions={{
        headerStyle: {
          backgroundColor: '#A9A9A9',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}>
        <Stack.Screen
          name="HomePage"
          component={WelcomePage}
        //   options={{ title: 'Welcome Page',   headerRight: () => (
        //     <Button
        //       onPress={() => alert('This is a button!')}
        //       title="Info"
        //       color="#fff"
        //     />
        //   ), }}
          
        />
        <Stack.Screen name="PageOne"  options={{ title: 'Page One' }} component={PageOne} />
        <Stack.Screen name="PageTwo"  options={{ title: 'Page Two' }} component={PageTwo} />
      </Stack.Navigator>
    </NavigationContainer>
  </Provider>
  );
};
export default MyStack;